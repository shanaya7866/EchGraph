from fastapi.testclient import TestClient
from app.main import app, answer_question

client = TestClient(app)

def test_home_serves_app():
    response = client.get('/')
    assert response.status_code == 200
    assert 'CompanyBrain' in response.text

def test_chat_rejects_empty_message():
    response = client.post('/api/chat', json={'message': ''})
    assert response.status_code == 422

def test_unknown_question_is_honest():
    result = answer_question('What is the secret recipe for moon cheese?')
    assert 'I can answer questions' in result['answer']
    assert result['evidence'] == []


def test_analytics_returns_graph_metrics(monkeypatch):
    from app import main

    def fake_rows(query, params=None):
        if query.strip() == "MATCH (i:Incident) RETURN count(i)":
            return [[3]]
        if "toLower(i.status)" in query:
            return [[1]]
        if "toLower(coalesce(i.status" in query:
            return [[2]]
        if "count(s)" in query:
            return [[3]]
        if "count(p)" in query and "Project" not in query:
            return [[4]]
        if "MATCH (p:Project)" in query:
            return [[2]]
        if "DEPENDS_ON" in query:
            return [[1]]
        if "coalesce(i.severity" in query:
            return [["SEV-2", 1], ["SEV-3", 2]]
        if "coalesce(i.status" in query:
            return [["Resolved", 2], ["Investigating", 1]]
        if "AFFECTED" in query:
            return [["Identity API", 1]]
        if "coalesce(i.date" in query:
            return [["2026-10-12", 1]]
        if "MEMBER_OF" in query:
            return [["Platform", 2, 1]]
        return []

    monkeypatch.setattr(main, "rows", fake_rows)
    response = client.get('/api/analytics')
    assert response.status_code == 200
    data = response.json()
    assert data['totals']['incidents'] == 3
    assert data['by_severity'][0] == {'name': 'SEV-2', 'count': 1}
    assert data['by_team'][0]['name'] == 'Platform'


def test_graph_backed_answer_includes_trace(monkeypatch):
    from app import main

    def fake_rows(query, params=None):
        if "MATCH (s:Service) OPTIONAL MATCH" in query:
            return [["Search Portal", "Operational", ["Identity API"], ["Beacon"]]]
        return []

    monkeypatch.setattr(main, "rows", fake_rows)
    result = answer_question("What services depend on other services?")
    assert result["intent"] == "service_dependencies"
    assert result["trace"]
    assert "DEPENDS_ON" in result["trace"][0]["path"]


def test_document_ingestion_validates_links(monkeypatch):
    from app import main

    def fake_rows(query, params=None):
        if "MATCH (i:Incident {id:$id}) RETURN i.id" in query:
            return [["INC-1042"]]
        if "MATCH (s:Service {name:$name}) RETURN s.name" in query:
            return [["Search Portal"]]
        return []

    monkeypatch.setattr(main, "rows", fake_rows)
    response = client.post("/api/documents", json={
        "title": "Search incident notes",
        "kind": "Runbook",
        "summary": "Steps to inspect the search service and queue lag.",
        "incident_id": "INC-1042",
        "service_name": "Search Portal",
        "source_url": "https://example.com/runbook"
    })
    assert response.status_code == 200
    assert response.json()["status"] == "saved"
