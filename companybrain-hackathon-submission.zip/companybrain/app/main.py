"""CompanyBrain: graph-grounded company knowledge assistant demo."""
from __future__ import annotations
import os, re
from typing import Any
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

try:
    from falkordb import FalkorDB
except ImportError:  # Allows the API's health page to explain missing dependencies.
    FalkorDB = None

APP_NAME = "CompanyBrain"
GRAPH_NAME = os.getenv("FALKORDB_GRAPH", "companybrain")
app = FastAPI(title=APP_NAME, version="1.1.0", description="Graph-grounded company knowledge assistant with explainable retrieval and persistent agent memory")
app.mount("/static", StaticFiles(directory="app/static"), name="static")


def get_graph():
    if FalkorDB is None:
        raise RuntimeError("FalkorDB client is not installed. Install requirements.txt.")
    db = FalkorDB(host=os.getenv("FALKORDB_HOST", "localhost"), port=int(os.getenv("FALKORDB_PORT", "6379")))
    return db.select_graph(GRAPH_NAME)


def rows(query: str, params: dict | None = None) -> list:
    return get_graph().query(query, params or {}).result_set


def safe_text(value: Any) -> str:
    return str(value or "").strip()


SCHEMA = [
    "CREATE INDEX FOR (n:Person) ON (n.name)",
    "CREATE INDEX FOR (n:Service) ON (n.name)",
    "CREATE INDEX FOR (n:Incident) ON (n.id)",
    "CREATE INDEX FOR (n:Project) ON (n.name)",
]

# Entirely fictional seed data. Idempotent by clearing only this demo graph before reseeding.
SEED_QUERIES = [
    "CREATE (p1:Person {name:'Maya Patel', role:'Platform Engineer', email:'maya@novatech.example'}), (p2:Person {name:'Arjun Shah', role:'Data Scientist', email:'arjun@novatech.example'}), (p3:Person {name:'Leena Rao', role:'Product Manager', email:'leena@novatech.example'}), (p4:Person {name:'Omar Khan', role:'SRE', email:'omar@novatech.example'})",
    "CREATE (t1:Team {name:'Platform'}), (t2:Team {name:'Data Science'}), (t3:Team {name:'Product'})",
    "CREATE (pr1:Project {name:'Atlas', status:'Active', summary:'Customer analytics platform'}), (pr2:Project {name:'Beacon', status:'Active', summary:'Internal knowledge search'})",
    "CREATE (s1:Service {name:'Identity API', status:'Degraded', owner:'Platform', criticality:'High'}), (s2:Service {name:'Event Pipeline', status:'Operational', owner:'Data Science', criticality:'High'}), (s3:Service {name:'Search Portal', status:'Operational', owner:'Platform', criticality:'Medium'})",
    "CREATE (i1:Incident {id:'INC-1042', title:'Identity API elevated latency', severity:'SEV-2', status:'Resolved', date:'2026-10-12', summary:'A connection-pool limit caused elevated login latency.'}), (i2:Incident {id:'INC-1051', title:'Delayed analytics events', severity:'SEV-3', status:'Investigating', date:'2026-10-16', summary:'A schema change caused retries in the event pipeline.'}), (i3:Incident {id:'INC-0998', title:'Search indexing backlog', severity:'SEV-3', status:'Resolved', date:'2026-09-28', summary:'A worker restart cleared a stale indexing queue.'})",
    "CREATE (d1:Document {title:'Identity API Runbook', kind:'Runbook', summary:'Check pool saturation, review recent deploys, and validate connection limits.'}), (d2:Document {title:'Event Schema Change RFC', kind:'RFC', summary:'Schema changes require compatibility checks and a staged rollout.'}), (d3:Document {title:'Search Operations Guide', kind:'Runbook', summary:'Inspect indexing queue depth and restart workers only after checking lag.'})",
    "CREATE (dc1:Decision {title:'Adopt staged schema rollout', date:'2026-08-20', summary:'All event schema changes use backward-compatible staged rollout.'}), (r1:Resolution {title:'Increase connection pool and add saturation alert', summary:'Raised the safe connection-pool limit, added saturation monitoring, and verified login latency returned to baseline.', confirmed:true}), (r2:Resolution {title:'Restart indexing worker after checking queue lag', summary:'Validated queue lag, restarted the stale worker, and confirmed the backlog drained.', confirmed:true})",
    "MATCH (p:Person {name:'Maya Patel'}),(t:Team {name:'Platform'}),(pr:Project {name:'Atlas'}) CREATE (p)-[:MEMBER_OF]->(t),(p)-[:WORKED_ON]->(pr)",
    "MATCH (p:Person {name:'Arjun Shah'}),(t:Team {name:'Data Science'}),(pr:Project {name:'Atlas'}) CREATE (p)-[:MEMBER_OF]->(t),(p)-[:WORKED_ON]->(pr)",
    "MATCH (p:Person {name:'Leena Rao'}),(t:Team {name:'Product'}),(pr:Project {name:'Beacon'}) CREATE (p)-[:MEMBER_OF]->(t),(p)-[:WORKED_ON]->(pr)",
    "MATCH (p:Person {name:'Omar Khan'}),(t:Team {name:'Platform'}) CREATE (p)-[:MEMBER_OF]->(t)",
    "MATCH (s1:Service {name:'Identity API'}),(s2:Service {name:'Event Pipeline'}),(s3:Service {name:'Search Portal'}),(pr1:Project {name:'Atlas'}),(pr2:Project {name:'Beacon'}) CREATE (s1)-[:PART_OF]->(pr1),(s2)-[:PART_OF]->(pr1),(s3)-[:PART_OF]->(pr2),(s3)-[:DEPENDS_ON]->(s1)",
    "MATCH (i:Incident {id:'INC-1042'}),(s:Service {name:'Identity API'}),(p:Person {name:'Maya Patel'}),(d:Document {title:'Identity API Runbook'}),(r:Resolution {title:'Increase connection pool and add saturation alert'}) CREATE (i)-[:AFFECTED]->(s),(p)-[:RESOLVED]->(i),(i)-[:DOCUMENTED_IN]->(d),(i)-[:FIXED_BY]->(r)",
    "MATCH (i:Incident {id:'INC-1051'}),(s:Service {name:'Event Pipeline'}),(p:Person {name:'Arjun Shah'}),(d:Document {title:'Event Schema Change RFC'}),(dc:Decision {title:'Adopt staged schema rollout'}) CREATE (i)-[:AFFECTED]->(s),(p)-[:INVESTIGATING]->(i),(i)-[:DOCUMENTED_IN]->(d),(dc)-[:GUIDES]->(s)",
    "MATCH (i:Incident {id:'INC-0998'}),(s:Service {name:'Search Portal'}),(d:Document {title:'Search Operations Guide'}),(r:Resolution {title:'Restart indexing worker after checking queue lag'}) CREATE (i)-[:AFFECTED]->(s),(i)-[:DOCUMENTED_IN]->(d),(i)-[:FIXED_BY]->(r)",
    "MATCH (pr:Project {name:'Beacon'}),(p:Person {name:'Leena Rao'}),(s:Service {name:'Search Portal'}) CREATE (p)-[:SPONSORS]->(pr),(pr)-[:USES]->(s)",
]

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=1000)

class MemoryRequest(BaseModel):
    incident_id: str = Field(min_length=3, max_length=40)
    title: str = Field(min_length=3, max_length=160)
    summary: str = Field(min_length=10, max_length=1200)
    confirmed: bool = True

class DocumentRequest(BaseModel):
    title: str = Field(min_length=3, max_length=180)
    kind: str = Field(default="Document", min_length=2, max_length=40)
    summary: str = Field(min_length=10, max_length=3000)
    incident_id: str | None = Field(default=None, max_length=40)
    service_name: str | None = Field(default=None, max_length=120)
    source_url: str | None = Field(default=None, max_length=1000)


def record(row):
    """Convert FalkorDB node/path values to plain JSON-safe strings."""
    out = {}
    if isinstance(row, (list, tuple)):
        return [record(x) for x in row]
    if hasattr(row, "properties"):
        return dict(row.properties)
    if isinstance(row, dict):
        return {str(k): record(v) for k, v in row.items()}
    if row is None or isinstance(row, (str, int, float, bool)):
        return row
    return str(row)

@app.get("/")
def home():
    return FileResponse("app/static/index.html")

@app.get("/api/health")
def health():
    try:
        result = rows("RETURN 1 AS ok")
        return {"status": "ok", "database": "connected", "graph": GRAPH_NAME, "check": result[0][0] if result else 1}
    except Exception as exc:
        return {"status": "degraded", "database": "unavailable", "graph": GRAPH_NAME, "detail": str(exc), "hint": "Start Docker Compose and wait for FalkorDB to become healthy."}

@app.post("/api/seed")
def seed():
    try:
        g = get_graph()
        g.query("MATCH (n) DETACH DELETE n")
        for q in SEED_QUERIES:
            g.query(q)
        for q in SCHEMA:
            try: g.query(q)
            except Exception: pass  # Index support can vary by FalkorDB version; data still works.
        return {"status": "seeded", "message": "NovaTech demo graph created.", "nodes": 0}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Could not seed FalkorDB: {exc}")

@app.get("/api/graph")
def graph():
    try:
        result = rows("MATCH (a)-[r]->(b) RETURN id(a), labels(a), properties(a), type(r), id(b), labels(b), properties(b) LIMIT 180")
        nodes, edges, ids = [], [], set()
        for x in result:
            aid, alabs, aprop, rel, bid, blabs, bprop = x
            for nid, labs, props in [(aid, alabs, aprop), (bid, blabs, bprop)]:
                if nid not in ids:
                    props = dict(props or {})
                    label = (labs or ["Node"])[0]
                    nodes.append({"id": str(nid), "label": props.get("name") or props.get("title") or props.get("id") or label, "type": label, "properties": props})
                    ids.add(nid)
            edges.append({"source": str(aid), "target": str(bid), "label": rel})
        return {"nodes": nodes, "edges": edges}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

@app.get("/api/analytics")
def analytics():
    """Return live descriptive analytics computed from the FalkorDB graph."""
    try:
        def scalar(query: str) -> int:
            result = rows(query)
            return int(result[0][0] or 0) if result else 0

        total_incidents = scalar("MATCH (i:Incident) RETURN count(i)")
        open_incidents = scalar("MATCH (i:Incident) WHERE i.status IS NULL OR toLower(i.status) <> 'resolved' RETURN count(i)")
        resolved_incidents = scalar("MATCH (i:Incident) WHERE toLower(coalesce(i.status, '')) = 'resolved' RETURN count(i)")
        service_count = scalar("MATCH (s:Service) RETURN count(s)")
        people_count = scalar("MATCH (p:Person) RETURN count(p)")
        project_count = scalar("MATCH (p:Project) RETURN count(p)")

        severity_rows = rows("MATCH (i:Incident) RETURN coalesce(i.severity, 'Unknown'), count(i) ORDER BY count(i) DESC")
        status_rows = rows("MATCH (i:Incident) RETURN coalesce(i.status, 'Unknown'), count(i) ORDER BY count(i) DESC")
        service_rows = rows("MATCH (i:Incident)-[:AFFECTED]->(s:Service) RETURN s.name, count(DISTINCT i) ORDER BY count(DISTINCT i) DESC LIMIT 8")
        date_rows = rows("MATCH (i:Incident) RETURN coalesce(i.date, 'Unknown date'), count(i) ORDER BY coalesce(i.date, 'Unknown date')")
        team_rows = rows("MATCH (p:Person)-[:MEMBER_OF]->(t:Team) OPTIONAL MATCH (p)-[:RESOLVED]->(i:Incident) RETURN t.name, count(DISTINCT p), count(DISTINCT i) ORDER BY t.name")
        dependency_count = scalar("MATCH (:Service)-[:DEPENDS_ON]->(:Service) RETURN count(*)")

        def pairs(items):
            return [{"name": str(x[0] or "Unknown"), "count": int(x[1] or 0)} for x in items]

        return {
            "totals": {"incidents": total_incidents, "open_incidents": open_incidents,
                       "resolved_incidents": resolved_incidents, "services": service_count,
                       "people": people_count, "projects": project_count,
                       "service_dependencies": dependency_count},
            "by_severity": pairs(severity_rows),
            "by_status": pairs(status_rows),
            "by_service": pairs(service_rows),
            "by_date": pairs(date_rows),
            "by_team": [{"name": str(x[0] or "Unknown"), "people": int(x[1] or 0),
                         "resolved_incidents": int(x[2] or 0)} for x in team_rows]
        }
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Analytics unavailable: {exc}. Check FalkorDB and load demo knowledge.")

@app.get("/api/incidents")
def incidents():
    try:
        data = rows("MATCH (i:Incident) OPTIONAL MATCH (i)-[:AFFECTED]->(s:Service) OPTIONAL MATCH (i)-[:DOCUMENTED_IN]->(d:Document) OPTIONAL MATCH (i)-[:FIXED_BY]->(r:Resolution) RETURN properties(i), collect(DISTINCT s.name), collect(DISTINCT d.title), collect(DISTINCT r.title) ORDER BY i.date DESC")
        return [{"incident": record(x[0]), "services": x[1] or [], "documents": x[2] or [], "resolutions": x[3] or []} for x in data]
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

@app.get("/api/documents")
def documents():
    """Return source documents and the graph records they are connected to."""
    try:
        data = rows("MATCH (d:Document) OPTIONAL MATCH (i:Incident)-[:DOCUMENTED_IN]->(d) OPTIONAL MATCH (d)-[:ABOUT_SERVICE]->(s:Service) RETURN properties(d), collect(DISTINCT i.id), collect(DISTINCT s.name) ORDER BY d.title")
        return [{"document": record(x[0]), "incidents": x[1] or [], "services": x[2] or []} for x in data]
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Documents unavailable: {exc}")


@app.post("/api/documents")
def add_document(req: DocumentRequest):
    """Ingest a document summary into the graph and optionally connect it to known entities."""
    try:
        incident_id = (req.incident_id or "").strip()
        service_name = (req.service_name or "").strip()
        if incident_id and not rows("MATCH (i:Incident {id:$id}) RETURN i.id", {"id": incident_id}):
            raise HTTPException(status_code=404, detail=f"Incident {incident_id} was not found.")
        if service_name and not rows("MATCH (s:Service {name:$name}) RETURN s.name", {"name": service_name}):
            raise HTTPException(status_code=404, detail=f"Service {service_name} was not found.")
        rows("MERGE (d:Document {title:$title}) SET d.kind=$kind, d.summary=$summary, d.sourceUrl=$source_url, d.updatedAt=timestamp()",
             {"title": req.title.strip(), "kind": req.kind.strip(), "summary": req.summary.strip(), "source_url": (req.source_url or "").strip()})
        if incident_id:
            rows("MATCH (i:Incident {id:$id}), (d:Document {title:$title}) MERGE (i)-[:DOCUMENTED_IN]->(d)",
                 {"id": incident_id, "title": req.title.strip()})
        if service_name:
            rows("MATCH (d:Document {title:$title}), (s:Service {name:$name}) MERGE (d)-[:ABOUT_SERVICE]->(s)",
                 {"title": req.title.strip(), "name": service_name})
        return {"status": "saved", "message": "Document added to FalkorDB and linked to the selected graph entities."}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Could not add document: {exc}")


@app.get("/api/memory")
def memories():
    try:
        data = rows("MATCH (r:Resolution) OPTIONAL MATCH (i:Incident)-[:FIXED_BY]->(r) RETURN properties(r), collect(i.id) ORDER BY r.title")
        return [{"resolution": record(x[0]), "incidents": x[1] or []} for x in data]
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

@app.post("/api/memory")
def add_memory(req: MemoryRequest):
    try:
        found = rows("MATCH (i:Incident {id:$id}) RETURN i.id", {"id": req.incident_id})
        if not found:
            raise HTTPException(status_code=404, detail="Incident ID was not found in the graph.")
        # Values are parameterized, never interpolated into Cypher.
        rows("CREATE (r:Resolution {title:$title, summary:$summary, confirmed:$confirmed, createdAt:timestamp()})", {"title": req.title, "summary": req.summary, "confirmed": req.confirmed})
        rows("MATCH (i:Incident {id:$id}), (r:Resolution {title:$title}) MERGE (i)-[:FIXED_BY]->(r)", {"id": req.incident_id, "title": req.title})
        return {"status": "saved", "message": "Resolution stored in FalkorDB graph memory."}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

@app.get("/api/agent/activity")
def agent_activity(limit: int = 20):
    """Recent persisted agent runs, useful for reviewing what the assistant did."""
    limit = max(1, min(limit, 100))
    try:
        data = rows("MATCH (m:AgentMemory) RETURN m.question, m.intent, m.answer, m.createdAt ORDER BY m.createdAt DESC LIMIT $limit", {"limit": limit})
        return [{"question": x[0], "intent": x[1], "answer": x[2], "created_at": x[3]} for x in data]
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Agent activity unavailable: {exc}")


def persist_agent_run(question: str, intent: str, answer: str):
    """Persist a compact trace so context survives browser/session restarts."""
    try:
        rows("CREATE (:AgentMemory {question:$question, intent:$intent, answer:$answer, createdAt:timestamp()})",
             {"question": question[:1000], "intent": intent[:60], "answer": answer[:3000]})
    except Exception:
        # Keep answer delivery resilient if optional activity storage fails.
        pass


# Intent-based, graph-grounded query templates. No free-form LLM-generated Cypher.
def answer_question(question: str) -> dict:
    q = question.lower().strip()
    result = {"answer": "", "evidence": [], "confidence": "medium", "trace": [], "intent": "unsupported"}
    try:
        if any(w in q for w in ["what did we discuss", "previous session", "last session", "remember my question", "agent activity", "conversation history"]):
            found = rows("MATCH (m:AgentMemory) RETURN m.question,m.intent,m.answer,m.createdAt ORDER BY m.createdAt DESC LIMIT 8")
            if not found:
                result.update(answer="I don't have any saved agent activity yet. Ask a graph-backed question first; CompanyBrain will save a compact activity record in FalkorDB.", evidence=["No AgentMemory nodes were found"], confidence="low", intent="session_memory")
            else:
                lines = [f"Earlier question: {x[0]} (intent: {x[1]}). Answer summary: {str(x[2])[:280]}" for x in found]
                result.update(answer="Here is recent activity remembered in the graph across sessions:\\n\\n" + "\\n".join(lines), evidence=["AgentMemory nodes stored in FalkorDB"], confidence="high", intent="session_memory", trace=[{"path":"(:AgentMemory) ordered by createdAt DESC","records":len(found)}])
        elif any(w in q for w in ["decision", "why did we choose", "rfc", "document", "runbook", "source", "policy"]):
            found = rows("MATCH (d:Document) OPTIONAL MATCH (i:Incident)-[:DOCUMENTED_IN]->(d) RETURN d.title,d.kind,d.summary,collect(DISTINCT i.id) ORDER BY d.title")
            decisions = rows("MATCH (d:Decision) OPTIONAL MATCH (d)-[:GUIDES]->(s:Service) RETURN d.title,d.date,d.summary,collect(DISTINCT s.name) ORDER BY d.date DESC")
            lines = [f"Document: {x[0]} ({x[1]}). Summary: {x[2]} Linked incidents: {', '.join(x[3] or []) or 'none linked'}." for x in found]
            lines += [f"Decision: {x[0]} ({x[1]}). Rationale: {x[2]} Guided services: {', '.join(x[3] or []) or 'none linked'}." for x in decisions]
            result.update(answer="Connected documents and decisions in the graph:\\n\\n" + ("\\n".join(lines) if lines else "No documents or decisions are recorded yet."), evidence=["Document nodes and Incident-[:DOCUMENTED_IN]->Document paths", "Decision-[:GUIDES]->Service paths"], confidence="high" if lines else "low", intent="documents_decisions", trace=[{"path":"(Incident)-[:DOCUMENTED_IN]->(Document)","records":len(found)}, {"path":"(Decision)-[:GUIDES]->(Service)","records":len(decisions)}])
        elif any(w in q for w in ["impact", "downstream", "what breaks", "affected by", "blast radius"]):
            found = rows("MATCH (s:Service)-[:DEPENDS_ON*1..4]->(dep:Service) RETURN s.name, collect(DISTINCT dep.name) ORDER BY s.name")
            lines = [f"{x[0]} depends transitively on: {', '.join(x[1] or [])}." for x in found]
            result.update(answer="Dependency impact paths found in FalkorDB:\\n\\n" + ("\\n".join(lines) if lines else "No multi-hop service dependency paths are recorded yet."), evidence=["Variable-length Service-[:DEPENDS_ON*1..4]->Service graph traversal"], confidence="high" if lines else "low", intent="impact_analysis", trace=[{"path":"(Service)-[:DEPENDS_ON*1..4]->(Service)","records":len(found)}])
        elif any(w in q for w in ["incident", "outage", "issue", "error", "problem", "severe", "sev-"]):
            found = rows("MATCH (i:Incident) OPTIONAL MATCH (i)-[:AFFECTED]->(s:Service) OPTIONAL MATCH (i)-[:DOCUMENTED_IN]->(d:Document) OPTIONAL MATCH (i)-[:FIXED_BY]->(r:Resolution) RETURN properties(i), collect(DISTINCT s.name), collect(DISTINCT d.title), collect(DISTINCT r.title) ORDER BY i.date DESC")
            if not found:
                result.update(answer="I couldn't find incident records in the graph. Seed the demo data first.", confidence="low", intent="incident_search")
            else:
                items = []
                for x in found:
                    i = dict(x[0]); items.append(f"{i.get('id')} ({i.get('severity')}, {i.get('status')}): {i.get('title')}. Service: {', '.join(x[1] or []) or 'not linked'}. Evidence: {', '.join(x[2] or []) or 'no document linked'}. Resolution: {', '.join(x[3] or []) or 'not recorded'}.")
                result.update(answer="Here are the incident records currently connected in CompanyBrain:\\n\\n" + "\\n".join(items), evidence=["Incident, service, document and resolution nodes returned from FalkorDB"], confidence="high", intent="incident_search", trace=[{"path":"(Incident)-[:AFFECTED]->(Service)","records":len(found)}, {"path":"(Incident)-[:DOCUMENTED_IN]->(Document)","records":len(found)}, {"path":"(Incident)-[:FIXED_BY]->(Resolution)","records":len(found)}])
        elif any(w in q for w in ["who", "owner", "responsible", "team", "person", "employee"]):
            found = rows("MATCH (p:Person)-[:MEMBER_OF]->(t:Team) OPTIONAL MATCH (p)-[:WORKED_ON]->(pr:Project) RETURN p.name,p.role,t.name,collect(DISTINCT pr.name) ORDER BY p.name")
            lines = [f"{x[0]} — {x[1]}, team {x[2]}; projects: {', '.join(x[3] or []) or 'none linked'}." for x in found]
            result.update(answer="People and team relationships in the graph:\\n\\n" + "\\n".join(lines), evidence=["Person-[:MEMBER_OF]->Team and Person-[:WORKED_ON]->Project relationships"], confidence="high", intent="people_ownership", trace=[{"path":"(Person)-[:MEMBER_OF]->(Team)","records":len(found)}, {"path":"(Person)-[:WORKED_ON]->(Project)","records":len(found)}])
        elif any(w in q for w in ["depend", "service", "project"]):
            found = rows("MATCH (s:Service) OPTIONAL MATCH (s)-[:DEPENDS_ON]->(dep:Service) OPTIONAL MATCH (s)-[:PART_OF]->(p:Project) RETURN s.name,s.status,collect(DISTINCT dep.name),collect(DISTINCT p.name) ORDER BY s.name")
            lines = [f"{x[0]} ({x[1]}); depends on: {', '.join(x[2] or []) or 'none recorded'}; project(s): {', '.join(x[3] or []) or 'none linked'}." for x in found]
            result.update(answer="Service dependencies and project links:\\n\\n" + "\\n".join(lines), evidence=["Service-[:DEPENDS_ON]->Service and Service-[:PART_OF]->Project graph paths"], confidence="high", intent="service_dependencies", trace=[{"path":"(Service)-[:DEPENDS_ON]->(Service)","records":len(found)}, {"path":"(Service)-[:PART_OF]->(Project)","records":len(found)}])
        elif any(w in q for w in ["resolution", "resolved", "fix", "memory", "learned", "remember"]):
            found = rows("MATCH (r:Resolution) OPTIONAL MATCH (i:Incident)-[:FIXED_BY]->(r) RETURN r.title,r.summary,r.confirmed,collect(i.id)")
            lines = [f"{x[0]} — {x[1]} Linked incidents: {', '.join(x[3] or []) or 'none'}. Confirmed: {x[2]}." for x in found]
            result.update(answer="Resolution memory retrieved from FalkorDB:\\n\\n"+("\\n".join(lines) if lines else "No resolution memory is stored yet."), evidence=["Resolution nodes and Incident-[:FIXED_BY]->Resolution links"], confidence="high", intent="resolution_memory", trace=[{"path":"(Incident)-[:FIXED_BY]->(Resolution)","records":len(found)}])
        else:
            result.update(answer="I can answer questions about incidents, people and teams, service dependencies and impact, projects, runbooks and decisions, recorded resolutions, and prior agent activity. Try: ‘Which incidents are open?’, ‘Who is on Platform?’, ‘What is the impact of the service dependencies?’, or ‘What decisions are documented?’. This prototype uses constrained graph-query templates rather than inventing answers.", evidence=[], confidence="medium", intent="unsupported")
        if result["intent"] != "unsupported" and result["intent"] != "session_memory":
            persist_agent_run(question, result["intent"], result["answer"])
        return result
    except Exception as exc:
        return {"answer":f"I couldn't query the knowledge graph: {exc}. Check that FalkorDB is running and seed the demo data.", "evidence":[], "confidence":"low", "trace":[], "intent":"error"}


@app.post("/api/chat")
def chat(req: ChatRequest):
    return answer_question(req.message.strip())
